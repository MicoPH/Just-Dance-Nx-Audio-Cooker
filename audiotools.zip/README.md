# Just-Dance-Nx-Amb-Maker
How To Convert Audio to wav.ckd (amb file) \
1.) You need short audio and Wave format \
2.) Drag the wav file into input folder \
3.) Click ambmaker.py \
4.) Results on output folder

